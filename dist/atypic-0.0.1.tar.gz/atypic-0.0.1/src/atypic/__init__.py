"""Video Effects Library: Add atypical artifacts to image frames."""

# Import effect modules here
from . import effects
from . import mask